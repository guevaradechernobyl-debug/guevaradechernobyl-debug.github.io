﻿=== Hornet Cursor Set ===

By: PandieBonf

Download: http://www.rw-designer.com/cursor-set/hornet

Author's description:

Sharing Hornet from Silksong! 🕷️
I originally planned to animate a bell beast moving around on the busy cursor, but the app crashed and I forgot to save… so now Hornet is just chilling on a bench instead. Still, I hope you like how the set turned out!

P.S. I was really hoping Silksong would take GOTY for Best Art Direction.

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.